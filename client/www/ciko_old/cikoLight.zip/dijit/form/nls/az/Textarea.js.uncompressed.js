define(
"dijit/form/nls/az/Textarea", // used by both the editor and textarea widgets to provide information to screen reader users
({
	"iframeEditTitle" : "Redaktə sahəsi",
	"iframeFocusTitle" : "Redaktə sahəsi çərçivəsi"
})
);
